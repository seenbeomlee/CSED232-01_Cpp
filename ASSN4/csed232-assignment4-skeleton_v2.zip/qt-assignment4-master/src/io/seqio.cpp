#include "io/seqio.h"

namespace as4::io
{
    namespace operators
    {
        /* Put your code here */
    }
}
