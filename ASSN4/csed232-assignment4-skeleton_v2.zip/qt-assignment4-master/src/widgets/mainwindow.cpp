#include "widgets/mainwindow.h"

namespace as4::widgets
{
    MainWindowWidget::MainWindowWidget()
    {
        /* Put your code here */
    }
}
