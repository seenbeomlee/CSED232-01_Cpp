#ifndef __AS4_SONGIO_H
#define __AS4_SONGIO_H

#include <istream>
#include <ostream>

#include "model/song.h"

namespace as4::io
{
    namespace operators
    {
        /* Put your code here */
    }
}

#endif
